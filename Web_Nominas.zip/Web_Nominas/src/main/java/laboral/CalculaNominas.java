package laboral;

/**
 * Clase CalculaNominas con metodo Main
 */
public class CalculaNominas {
	
	/**
	 * Metodo main
	 * @param args
	 */
	public static void main(String[] args) {
		
		//Codigo parte 1.
		//EjecucionParte1.ejecucion();
		
		//System.out.println("\n------------------------------------\n");
		
		//Codigo parte 2-1.
		//EjecucionParte2P1.ejecucion();
		
		//System.out.println("\n------------------------------------\n");
		
		//Codigo parte 2-2.
		//EjecucionParte2P2.ejecucion();
		
		//System.out.println("\n------------------------------------\n");
		
		//Codigo parte 2-3.
		//EjecucionParte2P3.ejecucion();
		
		//System.out.println("\n------------------------------------\n");
		
		//Codigo parte 2-4.
		//EjecucionParte2P4.ejecucion();
		
		//System.out.println("\n------------------------------------\n");
		
		//Codigo parte 2-5.
		//EjecucionParte2P5.ejecucion();
		
	}

}